var searchData=
[
  ['leer',['leer',['../classPunto.html#a84cc9b0ee2e5b00842e7bff819b80459',1,'Punto::leer()'],['../classCirculo.html#aa71efffb3b42eeaefd43743a8d34aa74',1,'Circulo::leer()']]]
];
