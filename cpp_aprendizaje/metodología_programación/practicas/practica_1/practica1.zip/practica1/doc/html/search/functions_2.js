var searchData=
[
  ['intervalo',['Intervalo',['../classIntervalo.html#a9b5b23dda7ee26b444898457959cb03d',1,'Intervalo::Intervalo()'],['../classIntervalo.html#a321e56ef7e1f4a774bd64cc2609156f4',1,'Intervalo::Intervalo(double cotaInferior, double cotaSuperior)'],['../classIntervalo.html#af70d523399465f51862977a303656c72',1,'Intervalo::Intervalo(double cotaInferior, double cotaSuperior, bool cerradoInferior, bool cerradoSuperior)']]]
];
