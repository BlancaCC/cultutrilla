var searchData=
[
  ['leer',['leer',['../intervalo_8h.html#a81ca561257a3eea794e139a64fdd6593',1,'intervalo.cpp']]]
];
