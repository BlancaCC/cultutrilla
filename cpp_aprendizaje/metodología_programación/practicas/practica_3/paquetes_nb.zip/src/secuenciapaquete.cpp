/**
   @file secuenciapaquete.cpp
   @author decsai.ugr.es
   @warning Código incompleto
**/
