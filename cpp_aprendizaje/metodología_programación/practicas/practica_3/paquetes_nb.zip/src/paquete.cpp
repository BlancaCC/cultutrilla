/**
   @file paquete.cpp
   @author decsai.ugr.es
   @warning Código incompleto
**/
